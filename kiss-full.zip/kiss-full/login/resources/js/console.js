
// When the webpage goest to fetch files, we intercept that request
// and serve up the matching files if we have them

window.addEventListener('load', function() {
    // console.log("loaded")
    // console.log(window.location)

    // set register and forgot password url
    //document.getElementById("kc-app-name").innerHTML = "Web Console";
    // console.log(window._path_.diktein_register)
    document.getElementById("kc-register-btn").href = window._path_.diktein_register;
    document.getElementById("kc-forgotpassword-btn").href = window._path_.diktein_reset;

    document.forms["kc-form-login"].addEventListener("submit", async (event) => {
        event.preventDefault();
        
        let formData = new FormData(event.target);
        const username = formData.get('username');
        const password = formData.get('password');

        // for (const value of formData.values()) {
        //     console.log(value);
        // }
        console.log(username,password)
        let hidden_login_form = document.forms['kc-form-login-hidden'];
        hidden_login_form.elements["username"].value = username; 
        hidden_login_form.elements["password"].value = sha256(password); 

        // hidden_login_formData = new FormData(hidden_login_form);

        // for (const value of hidden_login_formData.values()) {
        //     console.log(value);
        // }

        hidden_login_form.submit()
    });

    document.forms["kc-form-login-demo"].addEventListener("submit", async (event) => {
        event.preventDefault();
        
        let hidden_login_form = document.forms['kc-form-login-hidden'];
        hidden_login_form.elements["username"].value = 'demo'; 
        hidden_login_form.elements["password"].value = sha256('N0tul@'); 

        hidden_login_form.submit()
    });
});